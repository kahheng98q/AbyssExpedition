Extract all files, then double-click index.html.
35 original screenshots and their captions are included.
The game executable and user saves are not included.
To play, use Play Debug.cmd in your original project folder.
